<?php

namespace AI\Models;

class Image
{
    //
}